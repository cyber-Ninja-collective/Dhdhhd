# CNC Telegram Bot

## Setup

1. Upload `index.js`, `package.json`, and your Go files (`Hulk.go`, `httpflood.go`) to CPanel `nodejs` app folder.
2. Run `npm install`.
3. Ensure Go is available in CPanel.
4. In CPanel → **Setup Node.js App** → select path + run command `npm start` (or `node index.js`).
5. Make directory writable if logs are needed.

## Usage

- `/start` → show menu
- `/crash <url> <GET|POST>`
- `/httpflood <url> <threads> <GET|POST> <duration>`
- `/adduser <id>` and `/removeuser <id>` (Admin only)
- `/info` → show whitelisted IDs

Cooldown for non-owners = 60 seconds per command.